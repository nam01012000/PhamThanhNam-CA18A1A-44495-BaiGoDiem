"""
Author: Phạm Thanh Nam
Date: 17/09/2021
Problem:
The variables x and y refer to numbers. Write a code segment that prompts the user for
an arithmetic operator and prints the value obtained by applying that operator to x and y.
Solution:

"""
x = int(input("Enter value of x:"))
y = int(input("Enter value of y:"))
op = (input("Enter arithmetic operator:"))
tinh = 0
if op == '+':
      tinh = x + y
elif op == '-':
      tinh = x - y
elif op == '*':
      tinh = x * y
elif op == '/':
      tinh = x / y
elif op == '%':
      tinh = x % y
else:
     print("Invalid Character!")
print(x, op, y, "=", tinh)

