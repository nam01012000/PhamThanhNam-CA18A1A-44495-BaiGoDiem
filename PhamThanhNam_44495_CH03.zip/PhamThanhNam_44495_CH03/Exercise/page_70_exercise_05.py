"""
Author: pham thanh nam
Date: 16/09/2021
Problem:
Assume that the variable teststring refers to a string. Write a loop that prints
each character in this string, followed by its ASCII value.
Solution:
for i in range(7):
    print(chr(i))
"""
for i in range(7):
    print(chr(i))