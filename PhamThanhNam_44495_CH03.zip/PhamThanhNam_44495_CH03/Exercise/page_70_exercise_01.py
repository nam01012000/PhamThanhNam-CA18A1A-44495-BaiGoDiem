"""
Author: Pham Thanh Nam
Date: 16/9/2021
Problem:
Write the outputs of the following loops:
a.
print(count + 1, end = " ")
b. for count in range(1, 4):
print(count, end = " ")
c. for count in range(1, 6, 2):
print(count, end = " ")
d. for count in range(6, 1, –1):
print(count, end = " ")
Solution:
a. 12345
b. 123
c. 135
d. 65432
"""
