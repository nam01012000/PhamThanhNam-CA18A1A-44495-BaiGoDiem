"""
Author: pham thanh nam
Date: 16/09/2021
Problem:
Write a code segment that displays the values of the integers x, y, and z on a single
line, such that each value is right-justified with a field width of 6.
Solution:
x = int(input("nhap so thu nhat: "));
y = int(input("nhap so thu hai: "));
z = int(input("nhap so thu ba: "));
print('%6d %6d %6d' %(x,y,z))
"""
