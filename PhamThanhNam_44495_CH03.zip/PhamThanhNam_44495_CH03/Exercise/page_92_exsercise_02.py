"""
Author: Phạm Thanh Nam
Date: 18/09/2021
Problem:
The factorial of an integer N is the product of the integers between 1 and N, inclusive.
 Write a while loop that computes the factorial of a given integer N.
Solution:
a= int(input("nhạp N:"))
fac = 1
x=1
while (x <= a):
    fac  = fac  * x
    x += 1
print("The factorial:",fac)

"""
