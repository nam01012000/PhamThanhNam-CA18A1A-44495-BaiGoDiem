"""
Author: Phạm Thanh Nam
Date: 17/09/2021
Problem:
Write a loop that outputs the numbers in a list named salaries.
The outputs should beformatted in a column that is right-justified,
 with a field width of 12 and a precision of 2.
Solution:

"""
for tienluong in range(5):
    print("%12.2f" %tienluong)