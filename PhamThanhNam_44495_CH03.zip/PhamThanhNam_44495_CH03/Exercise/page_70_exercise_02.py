"""
Author: pham thanh nam
Date: 16/09/2021
Problem:
Write a loop that prints your name 100 times. Each output should begin on a
new line.
Solution:
for count in range(100):
    print("Pham Thanh Nam")
"""
for count in range(100):
    print("Pham Thanh Nam")