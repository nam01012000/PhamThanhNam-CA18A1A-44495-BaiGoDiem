"""
Author: Pham Thanh Nam
Date: 17/09/2021
Problem:
Assume that x refers to a number. Write a code segment that prints the number’s
absolute value without using Python’s abs function.
Solution:
"""
a= int(input("Enter a:"));
b=-a
print("Absolute value of x:",b)