"""
Author: Pham Thanh Nam
Date: 17/09/2021
Problem:
Explain how to check for an invalid input number and prevent it being used in a
program. You may assume that the user enters a number.
Solution:
Use the command to repeat a number in a certain range
and then enter from the keyboard a number, if it is within the range,
 print that number, otherwise, it will report an error to re-enter the number

"""