"""
Author: Phạm Thanh Nam
Date: 18/09/2021
Problem:
What is the maximum number of guesses necessary to guess correctly
a given number between the numbers N and M?
Solution:
The maximum number of guesses between two numbers is to
subtract the smaller number from the larger number
eg: between 0 and 10, guess 10 times to get the number to guess
"""