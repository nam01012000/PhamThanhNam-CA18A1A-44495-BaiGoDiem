"""
Author: Phạm Thanh Nam
Date: 17/09/2021
Problem:
Write a loop that counts the number of space characters in a string. Recall that the
space character is represented as ' '.
Solution:
"""
count = 0
a = input("nhap cau: ")
for i in a:
    if a == (' '):
        count += 1
    print(count)