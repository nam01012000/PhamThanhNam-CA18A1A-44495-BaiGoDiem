"""
Author: Pham Thanh Nam
Date: 17/09/2021
Problem:
Assume that the variables x and y refer to strings. Write a code segment that prints
these strings in alphabetical order. You should assume that they are not equal.
Solution:
kitu = my_str = "Pham Thanh Nam"
tu = [word.lower() for word in kitu.split()]
tu.sort()
print("Các từ được sắp xếp là: ")
for word in tu:
   print(word)
"""
