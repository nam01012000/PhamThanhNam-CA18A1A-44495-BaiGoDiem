"""
Author: Pham Thanh Nam
Date: 17/09/2021
Problem:
Write a format operation that builds a string for
the float variable amount that has
exactly two digits of precision and a field width of zero
Solution:
"""
a =float(input("nhap a:"))
print("%0.2f" %a)