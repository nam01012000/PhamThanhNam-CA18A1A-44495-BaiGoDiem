"""
Author: Phạm Thanh Nam
Date: 17/09/2021
Problem:
Construct truth tables for the following Boolean expressions:
a. not (A or B)
b. not A and not B
Solution:

"""
x =int(input("Enter x:"))
y =int(input("Enter y:"))
a=not(x or y)
print(a)
b= not x and not y
print(b)