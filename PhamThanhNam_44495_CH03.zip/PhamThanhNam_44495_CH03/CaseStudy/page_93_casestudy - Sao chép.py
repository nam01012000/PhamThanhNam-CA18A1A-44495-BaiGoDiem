"""
Author: Phạm Thanh Nam
 Compute the square root of a number.
1. The input is a number.
2. The outputs are the program's estimate of the square root
using Newton's method of successive approximations, and
Python's own estimate using math.sqrt.
"""
import math
a = float(input("Nhập một số dương: "))
tolerance = 0.000001
estimate = 1.0
while True:
 estimate = (estimate + a / estimate) / 2
 difference = abs(a - estimate ** 2)
 if difference <= tolerance:
     break
print("Ước tính của chương trình:", estimate)
print("Ước tính của Python: ", math.sqrt(a))
