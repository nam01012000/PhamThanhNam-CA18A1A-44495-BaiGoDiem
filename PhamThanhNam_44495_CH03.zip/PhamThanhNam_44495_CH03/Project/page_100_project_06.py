"""
Author: Phạm Thanh Nam
Date: 19/09/2021
Problem:
The German mathematician Gottfried Leibniz developed the following method
to approximate the value of π:
π/4 5 1 ] 1/3 1 1/5 ] 1/7 1 . . .
Write a program that allows the user to specify the number of iterations used in
this approximation and that displays the resulting value.
Solution:
number=float(input("Enter the number iterations: "))
pi=0
div=1
while(div <= number):
    positive_value = 4/(2*div-1)
    pi += positive_value
    div=div+2
div=2
while(div <= number):
    negative_value = 4/(2*div-1)
    pi -= negative_value
    div = div+2
print("Giá trị gần đúng của pi là %.16f "%pi)
"""
