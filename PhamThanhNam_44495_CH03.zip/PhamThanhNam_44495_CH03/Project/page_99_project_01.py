"""
Author: Phạm Thanh Nam
Date: 19/09/2021
Problem:Write a program that accepts the lengths of three sides of a triangle as inputs.
The program output should indicate whether or not the triangle is an equilateral triangle.

Solution:

"""
a= int(input("Enter the lengths of a:"))
b= int(input("Enter the lengths of b:"))
c= int(input("Enter the lengths of c:"))
if a==b==c:
    print("The triangle is an equilateral triangle")
else:
    print("the triangle isn't an equilateral triangle.")