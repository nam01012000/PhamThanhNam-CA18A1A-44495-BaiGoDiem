"""
Author: Phạm Thanh Nam
Date: 09/10/2021
Problem:
Make the following modifications to the original sentence-generator program:
a. The prepositional phrase is optional. (It can appear with a certain
probability.)
b. A conjunction and a second independent clause are optional: The boy took a
drink and the girl played baseball.
c. An adjective is optional: The girl kicked the red ball with a sore foot.
You should add new variables for the sets of adjectives and conjunctions.
Solution:

"""
import random
baiviet = ("A", "THE")
N = ("BOY", "GIRL", "BAT", "BALL",)
V = ("HIT", "SAW", "LIKED")
GioiTu = ("WITH", "BY")
def sentence():
     return nounPhrase() + " " + verbPhrase()
def nounPhrase():
    return random.choice(baiviet) + " " + random.choice(N)
def verbPhrase():
    return random.choice(V) + " " + nounPhrase() + " " + prepositionalPhrase()
def prepositionalPhrase():
    return random.choice(GioiTu)+ " " + nounPhrase()
def main():
    number = input("Enter the number of sentences: ")
    for count in range(0, number):
        print(sentence())
main()