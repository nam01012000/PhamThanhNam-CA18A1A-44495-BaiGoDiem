"""
Author: Phạm Thanh Nam
Date: 09/10/2021
Problem:
 Define a function named repToDecimal that expects two arguments, a string, and an integer. The second
argument should be the base. For example, repToDecimal("10", 8) returns 8, whereas repToDecimal("10", 16)
returns 16. The function should use a lookup table to find the value of any digit. Make sure that this table
 (it is actually a dictionary) is initialized before the function is defined. For its keys, use the 10
decimal digits (all strings) and the letters A . . . F (all uppercase). The value stored
with each key should be the integer that the digit represents. (The letter 'A' associates
 with the integer value 10, and so on.) The main loop of the function should
convert each digit to uppercase, look up its value in the table, and use this value
in the computation. Include a main function that tests the conversion function
with numbers in several bases.
Solution:

"""