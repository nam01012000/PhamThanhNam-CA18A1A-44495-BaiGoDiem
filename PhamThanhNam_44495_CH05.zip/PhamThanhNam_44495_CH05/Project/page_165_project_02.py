"""
Author: Phạm Thanh Nam
Date: 09/10/2021
Problem:
Write a program that allows the user to navigate the lines of text in a file. The
program should prompt the user for a filename and input the lines of text into a
list. The program then enters a loop in which it prints the number of lines in the
file and prompts the user for a line number. Actual line numbers range from 1 to
the number of lines in the file. If the input is 0, the program quits. Otherwise, the
program prints the line associated with that number.
Solution:

"""
NhapFile = input("Nhập tên file: ")
file = open(NhapFile, 'r')
SoDong = 0
for Dong in file:
    SoDong = SoDong + 1
print("số dòng trong txt. file là:", SoDong)
linenumber = 0
while True:
 number = int(input("Vui lòng nhập số dòng hoặc nhấn 0 để thoát: "))
if number >=1 and number <= SoDong:
    file = open(enterfile, 'r')
    for lines in file:
        linenumber = linenumber + 1
        if linenumber == number:
            print(lines)
else:
    if number == 0:
        print("Cảm ơn vì đã sử dụng chương trình")
