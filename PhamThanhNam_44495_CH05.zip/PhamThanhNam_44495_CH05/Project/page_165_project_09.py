"""
Author: Phạm Thanh Nam
Date: 10/10/2021
Problem:

Solution:

"""