"""
Author: Phạm Thanh nam
Date: 10/10/2021
Problem:
Write a program that inputs a text file. The program should print the unique
words in the file in alphabetical order.
Solution:

"""
word_list = []
TenFile = input("nhập tên:")
with open(TenFile) as words:
 for Dong in words:
     Dong.rstrip()
     for list_of_words in Dong.split():
         print(list_of_words)
         word_list.sort()
     for list2_words in word_list:
         if list2_words not in word_list:
             word_list.sort()
             word_list.append(list_of_words)
     for new_words in Dong.split():
          print(new_words)