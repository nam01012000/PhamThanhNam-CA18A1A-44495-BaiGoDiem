"""
Author: Phạm Thanh Nam
Date: 10/10/2021
Problem:
A file concordance tracks the unique words in a file and their frequencies. Write
a program that displays a concordance for a file. The program should output the
unique words and their frequencies in alphabetical order. Variations are to track
sequences of two words and their frequencies, or n words and their frequencies.
Solution:

"""
TenFile=input('nhập tên: ')
inputFile = open(TenFile,"r+")
list={}
for W in inputFile.read().split():
  if W not in list:
     list[W] = 1
  else:
     list[W] += 1
inputFile.close();
print();