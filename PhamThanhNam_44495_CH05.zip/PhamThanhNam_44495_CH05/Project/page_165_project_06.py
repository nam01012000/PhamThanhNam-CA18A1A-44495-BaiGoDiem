"""
Author: Phạm Thanh Nam
Date: 09/10/2021
Problem:
Define a function decimalToRep that returns the representation of an integer in a
given base. The two arguments should be the integer and the base. The function
should return a string. It should use a lookup table that associates integers with
digits. Include a main function that tests the conversion function with numbers
in several bases.
Solution:

"""
def decimalToRep(number,base):
    base1 = ""
    while number > 0:
        one = int(number % base1)
        if one < 10:
            base1 += str(one)
        else:
            base1 += chr(ord('A')+one-10)
        number //= base
    base1 = base1[::-1]
    return base1
def main():
    print(decimalToRep(10, 10))
    print(decimalToRep(10, 8))
    print(decimalToRep(10, 2))
    print(decimalToRep(10, 16))
if __name__ == "__main__":
    main()