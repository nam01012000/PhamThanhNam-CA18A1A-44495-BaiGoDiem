"""
Author: Phạm Thanh Nam
Date: 07/10/2021
Problem:

Solution:

"""
import random
Baiviet = ("A", "THE")
N = ("BOY", "GIRL", "BAT", "BALL")
V = ("HIT", "SAW", "LIKED")
Gioitu = ("WITH", "BY")
def sentence():
 return nounPhrase() + " " + verbPhrase()
def nounPhrase():
 return random.choice(Baiviet) + " " + random.choice(N)
def verbPhrase():
 return random.choice(V) + " " + nounPhrase() + " " + \
prepositionalPhrase()
def prepositionalPhrase():
 return random.choice(Gioitu) + " " + nounPhrase()
def main():
 number = int(input("Enter the number of sentences: "))
for count in range(1):
 print(sentence())
if __name__ == "__main__":
 main()