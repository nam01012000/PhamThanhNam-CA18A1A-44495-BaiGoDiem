"""
Author: Phạm Thanh Nam
Date: 07/10/2021
Problem:
Conducts an interactive session of nondirective
psychotherapy
Solution:

"""
import random
hed = ("Please tell me more.",
          "Many of my patients tell me the same thing.",
           "Please continue.")
qual = ("Why do you say that ",
               "You seem to think that ",
               "Can you explain why ")
rep = {"I":"you", "me":"you", "my":"your",
                "we":"you", "us":"you", "mine":"yours"}
def reply(sentence):
 probability = random.randint(1, 4)
 if probability == 1:
    return random.choice(hed)
 else:
    return random.choice(qual) + changePerson(sentence)
def changePerson(sentence):
 words = sentence.split()
 replyWords = []
 for i in words:
  replyWords.append(rep.get(i, i))
 return " ".join(replyWords)
def main():
 print("Good morning, I hope you are well today.")
 print("What can I do for you?")
 while True:
  sentence = input("\n>> ")
 if sentence.upper() == "QUIT":
  print("Have a nice day!")
  print(reply(sentence))
