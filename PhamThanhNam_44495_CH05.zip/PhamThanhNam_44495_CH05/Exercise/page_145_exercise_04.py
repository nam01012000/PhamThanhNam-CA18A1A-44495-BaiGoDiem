"""
Author: Phạm Thanh Nam
Date: 08/10/2021
Problem:
Write a loop that accumulates the sum of the numbers in a list named data.
Solution:
def listsum(numList):
    Tong = 0
    for i in numList:
        Tong = Tong + i
    return Tong
"""
def listsum(numList):
    Tong = 0
    for i in numList:
        Tong = Tong + i
    return Tong