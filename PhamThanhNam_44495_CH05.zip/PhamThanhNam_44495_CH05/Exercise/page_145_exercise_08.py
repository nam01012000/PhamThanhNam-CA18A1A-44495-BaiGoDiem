"""
Author: Phạm Thanh Nam
Date: 08/10/2021
Problem:
Explain the difference between structural equivalence and object identity.
Solution:
 The owner of the work is designed for a situation where the structure of the object is not included.
 Here, 2 objects are designed to be identical based on having the same properties.
The structure of the structure is designed to extend 2 specified nodes connected
to the same public space embedded in the equilibrium equations.
Frankly, structural equation refers to the level at which two nodes
are connected - that is, they have the same social locations
"""