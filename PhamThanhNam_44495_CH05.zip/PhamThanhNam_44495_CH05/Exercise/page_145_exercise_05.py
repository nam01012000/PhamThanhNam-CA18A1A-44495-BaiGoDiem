"""
Author: Phạm Thanh Nam
Date: 08/10/2021
Problem:
Assume that data refers to a list of numbers, and result refers to an empty list.
Write a loop that adds the nonzero values in data to the result list, keeping them
in their relative positions and excluding the zeros.
Solution:
data = [7, 50, 0, 30, 9, 92]
result = ""
for N in data:
   if N != 0:
       result += str(N)
"""
data = [7, 50, 0, 30, 9, 92]
result = ""
for N in data:
   if N != 0:
       result += str(N)