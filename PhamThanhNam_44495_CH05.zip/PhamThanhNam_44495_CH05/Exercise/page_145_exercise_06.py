"""
Author: Phạm Thanh Nam
Date: 08/10/2021
Problem:
Write a loop that replaces each number in a list named data with its absolute value.
Solution:
test_list = [5, -4, 10, -5, -17]
print("Danh sách ban đầu là : " + str(test_list))
res = [abs(ele) for ele in test_list]
print("Danh sách giá trị tuyệt đối : " + str(res))
"""
test_list = [5, -4, 10, -5, -17]
print("Danh sách ban đầu là : " + str(test_list))
res = [abs(ele) for ele in test_list]
print("Danh sách giá trị tuyệt đối : " + str(res))