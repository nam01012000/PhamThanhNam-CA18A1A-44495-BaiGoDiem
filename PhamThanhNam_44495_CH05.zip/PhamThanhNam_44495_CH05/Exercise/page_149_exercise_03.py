"""
Author: Phạm Thanh Nam
Date: 09/10/2021
Problem:Use the function even to simplify the definition of the function odd presented in
this section.

Solution:
def even(n):
    if n%2 == 0:
        return True
        return False


"""
def even(a):
    if a%2 == 0:
        return True
        return False