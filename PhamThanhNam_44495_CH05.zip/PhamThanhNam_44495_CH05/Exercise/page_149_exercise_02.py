"""Author: Phạm Thanh Nam
Date:09/10/2021
Problem:
Define a function named even. This function expects a number as an argument and
returns True if the number is divisible by 2, or it returns False otherwise. (Hint: A
number is evenly divisible by 2 if the remainder is 0.)

Solution:
def odd(i):
 if i%2 :
    return True
 else:
    return False


"""

def odd(i):
 if i%2 :
    return True
 else:
    return False