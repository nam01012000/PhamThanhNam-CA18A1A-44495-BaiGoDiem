"""
Author: Phạm Thanh Nam
Date: 18/10/2021
Problem:
Define and test a function named posterize. This function expects an image and a tuple of RGB
values as arguments. The function modifies the image like the blackAndWhite function, but it uses the given
RGB values instead of black.
Solution:
This module supports simple image processing.  The Image class represents
either an image loaded from a GIF file or a blank image.  To instantiate
an image from a file, enter

image = Image(aGifFileName)

To instantiate a blank image, enter

image = Image(aWidth, aHeight)

Image methods:

draw()                          Displays the image in a window
getWidth()  -> anInt            The width in pixels
getHeight() -> anInt            The height in pixels
getPixel(x, y)  -> (r, g, b)    The RGB values of pixel at x, y
setPixel(x, y, (r, g, b))       Resets pixel at x, y to (r, g, b)
save()                          Saves the image to the current file name
save(aFileName)                 Saves the image to fileName
"""
