"""
Author: Phạm Thanh Nam
Date: 18/10/2021
Problem: Inverting an image makes it look like a photographic negative. Define and test
a function named invert. This function expects an image as an argument and
resets each RGB component to 255 minus that component. Be sure to test the
function with images that have been converted to grayscale and black and white
as well as color images.
Solution:
"""