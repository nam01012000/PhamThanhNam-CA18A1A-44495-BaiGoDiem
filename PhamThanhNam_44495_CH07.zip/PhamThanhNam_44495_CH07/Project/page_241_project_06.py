"""
Author: Phạm Thanh Nam
Date: 18/10/2021
Problem: Define a second version of the grayscale function that uses the allegedly crude
method of simply averaging each RGB value. Test the function by comparing its
results with those of the other version discussed in this chapter.
Solution: Compares two different grayscale methods.
Solution:
"""