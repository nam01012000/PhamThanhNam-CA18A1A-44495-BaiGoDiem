"""
Author: Phạm Thanh Nam
Date: 17/10/2021
Problem: How would a column-major traversal of a grid work? Write a code segment that prints the positions
visited by a column-major traversal of a 2-by-3 grid.
Solution:
"""
width = 2
height = 3
for a in range(height):
    for b in range(width):
        print((a, b), end = " ")
    print()
