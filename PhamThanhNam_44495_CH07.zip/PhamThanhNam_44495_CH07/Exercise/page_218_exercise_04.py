"""
Author: Phạm Thanh Nam
Date: 16/10/2021
Problem:The functions that draw polygons in the polygons module have the same pattern, varying
only in the number of sides (iterations of the loop). Factor this pattern into a more general
function named polygon, which takes the number of sides as an additional argument.
Solution:

"""
import math
def polygon(sides, radius=1, rotation=0, translation=None):
    one_segment = math.pi * 2 / sides
    points = [
        (math.sin(one_segment * i + rotation) * radius,
         math.cos(one_segment * i + rotation))
        for i in range(sides)]
    if translation:
        points = [[sum(pair) for pair in zip(point, translation)]
                  for point in points]
    return points
