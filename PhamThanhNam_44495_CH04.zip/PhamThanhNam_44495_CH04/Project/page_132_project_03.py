"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
Modify the scripts of Projects 1 and 2 to encrypt and decrypt entire files of text.
Solution:
plainText = input("Enter a message: ")
distance = int(input("Enter the distance value: "))
code = ""
for ch in plainText:
   ordValue = ord (ch)
   cipherValue = ordValue + distance
  if cipherValue > 127:
   cipherValue distance (127 ordValue + 1).
   code + chr(cipherValue)
print(code)

"""
