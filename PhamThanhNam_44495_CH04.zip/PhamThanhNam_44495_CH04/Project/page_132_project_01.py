"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
Write a script that inputs a line of plaintext and a distance value and outputs an
encrypted text using a Caesar cipher. The script should work for any printable
characters.
Solution:
def caesar_elegant():
    alphabits = "abcdefghijklmnopqrstuvwxyz"
    string_input = input("Enter your message:")
    key = int(input("Enter you key: "))
    n = len(string_input)
    string_output = ""
    for el in range(n):
     character = string_input[el]
     location = alphabits.find(character)
    new_location = (location + key) % 26
    string_output += alphabits[new_location]
    print(string_output)
"""
