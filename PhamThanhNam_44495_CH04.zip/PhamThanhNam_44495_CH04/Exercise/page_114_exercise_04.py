"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
Translate each of the following numbers to decimal numbers:
a. 478
b. 1278
c. 648
Solution:
Translation of given octal numbers (base 8) to decimal numbers (base 10)
a.47 with base 8
  47 = (4 × 8¹) + (7 × 8°) = 39 base 10
b.127 with base 8
  127 = (1 × 8²) + (2 × 8¹) + (7 × 8°) = 87 base 10
c.64 with base 8
  64 = (6 × 8¹) + (4 × 8°) = 52 base 10
"""