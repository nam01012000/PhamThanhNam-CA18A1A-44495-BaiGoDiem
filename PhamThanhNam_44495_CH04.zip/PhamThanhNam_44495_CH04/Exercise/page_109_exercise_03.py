"""
Author: Phạm Thanh Nam
Date: 25/09/2021
Problem:
You are given a string that was encoded by a Caesar cipher with an unknown distance value. The text can contain any of the printable ASCII characters. Suggest an
algorithm for cracking this code.
Solution:
plainText = "Thanh Nam"
for c in plainText:
    ordvalue = ord(c)
    print(ordvalue)
"""
