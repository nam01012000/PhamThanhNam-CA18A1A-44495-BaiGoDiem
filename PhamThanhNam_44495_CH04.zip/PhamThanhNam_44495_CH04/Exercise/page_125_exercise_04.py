"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
Write a code segment that prints the names of all of the items in the current
working directory.
Solution:
attached in img_20210325_234634_683.jpg
img_20210325_234643_938.jpg
"""