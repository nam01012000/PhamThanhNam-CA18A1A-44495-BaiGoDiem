"""
Author: Phạm Thanh Nam
Date: 25/09/2021
Problem:
Write the encrypted text of each of the following words using a Caesar cipher with
a distance value of 3:
a. python
b. hacker
c. wow
Solution:
plainText = input("python: ")
distance = int(input("3: "))
code = ""
for c in plainText:
          ordValue = ord(c)
          cipherValue = ordValue + distance
          if cipherValue > ord('z'):
             cipherValue = ord('a')  + distance - \
        (ord('z') - ordValue + 1)
plainText = input("hacker: ")
distance = int(input("3: "))
code = ""
for c in plainText:
          ordValue = ord(c)
          cipherValue = ordValue + distance
          if cipherValue > ord('z'):
             cipherValue = ord('a')  + distance - \
        (ord('z') - ordValue + 1)
plainText = input("[wow]: ")
distance = int(input("3: "))
code = ""
for c in plainText:
          ordValue = ord(c)
          cipherValue = ordValue + distance
          if cipherValue > ord('z'):
             cipherValue = ord('a')  + distance - \
        (ord('z') - ordValue + 1)

"""
