"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
Write a code segment that opens a file for input and prints the number of
four-letter words in the file.
Solution:

"""