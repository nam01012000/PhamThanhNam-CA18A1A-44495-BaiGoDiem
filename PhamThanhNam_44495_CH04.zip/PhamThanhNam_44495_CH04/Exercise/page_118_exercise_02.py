"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
Using the value of data from Exercise 1, write the values of the following
expressions:
a. data.endswith('i')
b. " totally ".join(data.split())
Solution:
a. data.endswith('i')
   False
b. " totally ".join(data.split())
  'Python totally rules!'
"""