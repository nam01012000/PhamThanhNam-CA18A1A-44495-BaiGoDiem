"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
Translate each of the following numbers to binary numbers:
a. 478
b. 1278
c. 648
Solution:

"""
