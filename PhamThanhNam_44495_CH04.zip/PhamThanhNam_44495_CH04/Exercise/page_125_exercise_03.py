"""
Author: Le Trong
Date: 25/09/2021
Problem:
Assume that a file contains integers separated by newlines. Write a code segment
that opens the file and prints the average value of the integers.
Solution:
dem = 0
tong = 0
inputFile = open("myfile.txt",'r')
for line in inputFile:
   tong +=int(line.strip())
dem += 1
if dem  == 0:
    average = 0
else:
    average = tong /dem
print("The average is", average)
"""
