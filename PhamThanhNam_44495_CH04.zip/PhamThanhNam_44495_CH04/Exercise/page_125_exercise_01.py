"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
Write a code segment that opens a file named myfile.txt for input and prints the
number of lines in the file.
Solution:
#include
using namespace std;
int main()
   FILE *fp;
   char ch[1000];
 fp = fopen(myfile.txt, w);
 printf(Enter contents to store in file : \n);
 fgets(ch,1, stdin);
 fputs(data, fp);
 fclose(fp);
   int linesCount=0;
"""

