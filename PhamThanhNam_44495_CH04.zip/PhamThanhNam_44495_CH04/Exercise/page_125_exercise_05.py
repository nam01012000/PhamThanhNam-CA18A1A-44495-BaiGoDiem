"""
Author: Phạm Thanh Nam
Date: 26/09/2021
Problem:
 Write a code segment that prompts the user for a filename. If the file exists, the
program should print its contents on the terminal. Otherwise, it should print an
error message.
Solution:
dataobject = DataTransferinFiles()
Should be just:
dataobject = DataTransferinFiles()
So the full code:
class DataTransferinFiles():
 def transfer(self,firstfilename,secondfilename):
  print("your first file is=",firstfilename);
print("your second file is =", secondfilename)
with open(firstfilename,'r')as filedata:
    firstfiledata= filedata.readlines()
print()
print("1st file reading complete")
print()
with open(secondfilename, 'r')as filedata:
      secondfiledata=filedata.readlines()
print("2st file reading complete")
for eachline in firstfiledata:
    filesecond = open(secondfilename,'a')
filesecond.write("/n"+eachline+ "/n")
print ("1st file transfered in to second file")
for eachline in secondfiledata:
    filefirst = open(firstfilename)
filefirst.write("\n"+eachline+ "\n")
print ("second file transfered in to first file")
dataobject = DataTransferinFiles()
firstfilename = input("enter first file name for transfer")
secondfilename = input("enter second file name for transfer")
"""
