"""
Author: Phạm Thanh Nam
Date: 25/09/2021
Problem:
Translate each of the following numbers to decimal numbers:
a. (11001)2
b. (100000)2
c. (11111)2
Solution:
a. 11001  >>> 25
b. 100000 >>> 32
c. 11111  >>> 31
"""