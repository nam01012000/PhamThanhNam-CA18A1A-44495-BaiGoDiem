"""
Author: phạm thanh nam
Date: 23/10/2021
Problem:
 Describe the costs and benefits of defining and using a recursive function.
Solution:
 It uses system stack to accomplish it's task. As stack uses LIFO approach and when a function
     is called the controlled is moved to where function is defined which has it is stored in memory
     with some address, this address is stored in stack
 Recursion adds clarity and (sometimes) reduces the time needed to write and debug code
    (but doesn't necessarily reduce space requirements or speed of execution).
 Reduces time complexity
 Performs better in solving problems based on tree structures.
"""
